UPDATE vendor_address
SET vendor_address1 = '1990 Westwood Blvd',
    vendor_address2 = 'Ste 260'
WHERE vendor_id = 4
