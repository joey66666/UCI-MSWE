ALTER TABLE members
  ADD annual_dues   DECIMAL(5,2)    DEFAULT 52.50;
ALTER TABLE members
  ADD payment_date  DATE;

  
  
     
    
