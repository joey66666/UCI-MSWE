REVOKE ALL, GRANT OPTION 
FROM jim;

REVOKE ALL, GRANT OPTION 
FROM ap_user, anne@localhost;

REVOKE INSERT, UPDATE
ON ap.vendors FROM joel@localhost