SELECT *, CHAR(argument) AS argument_text FROM mysql.general_log;

SELECT * FROM mysql.slow_log;
