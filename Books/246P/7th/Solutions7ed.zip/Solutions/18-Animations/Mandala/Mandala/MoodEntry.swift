// 
//  Copyright © 2020 Big Nerd Ranch
//

import Foundation

struct MoodEntry {
    var mood: Mood
    var timestamp: Date
}
