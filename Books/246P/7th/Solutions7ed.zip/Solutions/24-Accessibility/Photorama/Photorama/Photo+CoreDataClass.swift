// 
//  Copyright © 2020 Big Nerd Ranch
//

import Foundation
import CoreData

@objc(Photo)
public class Photo: NSManagedObject {

}
